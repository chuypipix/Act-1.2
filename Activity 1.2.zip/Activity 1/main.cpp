// =================================================================
//
// File: main.cpp
// Author: Jesús Sánchez López A01709189
// Date: 6th of September, 2022
//
// =================================================================
#include <iostream>
#include <vector>
#include <fstream>
#include "header.h"
#include "search.h"
#include "bubble.h"
#include "selection.h"
#include "insertion.h"

using namespace std;

int main(int argc, char* argv[]) {
	//Input&Output files are opened
	std::fstream InputFile;
	std::fstream OutputFile;
	//Input&Output files are named
	InputFile.open(/*argv[2]*/"input4.txt",ios::in);
	OutputFile.open(/*argv[3]*/"mysolution4.txt",ios::out);
	//The size of the elements vector is taken as str and converted to int
	int Size,Element,Index=0;
	std::string Line,StringSize,StringElement;
	std::getline(InputFile,StringSize);
	Size=stoi(StringSize);
	//The elements vector is filled
	std::vector <int> Elements2Sort(Size);
	std::getline(InputFile,Line);
	for (int i = 0; i < Line.size();i++){
		if (Line[i]==' ' || Line[i]=='\n'){
			Element=stoi(StringElement);
			Elements2Sort[Index]=Element;
			Index++;
			StringElement=' ';
		}
		else{
			StringElement+=Line[i];
		}
	}
	//Auxiliary vector is set and variables are reseted
	std::vector <int> CopyElements2Sort=Elements2Sort;
	Element=0;
	Index=0;
	Size=0;
	//The vector of elements to be found is filled
	std::getline(InputFile,StringSize);
	Size=stoi(StringSize);
	std::vector <int> Elements2Find(Size);
	std::getline(InputFile,Line);
	for (int i = 0; i < Line.size();i++){
		if (Line[i]==' ' || Line[i]=='\n'){
			Element=stoi(StringElement);
			Elements2Find[Index]=Element;
			Index++;
			StringElement=' ';
		}
		else{
			StringElement+=Line[i];
		}
	}
	//Writes count comparisons of each algorith and resets it to 0 
	bubbleSort(Elements2Sort);
	OutputFile<<count()-1<<" ";
	Elements2Sort=CopyElements2Sort;
	count(1);
	selectionSort(Elements2Sort);
	OutputFile<<count()-1<<" ";
	Elements2Sort=CopyElements2Sort;
	count(1);
	insertionSort(Elements2Sort);
	OutputFile<<count()-1<<endl<<endl;
	//Writes comparisons of serching algorithms
	for (int i = 0; i < Elements2Find.size();i++){
		count(1);
		OutputFile<<sequentialSearch(Elements2Sort,Elements2Find[i])<<" "<<count()<<" ";
		count(1);
		binarySearch(Elements2Sort,Elements2Find[i]);
		OutputFile<<count()<<endl;
	}
	InputFile.close();
	OutputFile.close();
	return 0;
}
